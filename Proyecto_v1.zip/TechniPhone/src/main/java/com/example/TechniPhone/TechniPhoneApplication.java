package com.example.TechniPhone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TechniPhoneApplication {

	public static void main(String[] args) {
		SpringApplication.run(TechniPhoneApplication.class, args);
	}

}
