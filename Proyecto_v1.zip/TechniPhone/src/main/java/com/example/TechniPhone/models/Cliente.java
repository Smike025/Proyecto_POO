/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.TechniPhone.models;

import jakarta.persistence.*;
import lombok.EqualsAndHashCode;
/**
 *
 * @author suria
 */


@Entity
@Table(name = "Cliente")
@EqualsAndHashCode(callSuper = true)
public class Cliente extends Persona {
    @Id
    @Column(name = "idCliente")
    private int idCliente;
    
    @Column(name = "dui", unique = true, length = 10)
    private String dui;
    
    @Column(name = "direccion", columnDefinition = "TEXT")
    private String direccion;

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public String getDui() {
        return dui;
    }

    public void setDui(String dui) {
        this.dui = dui;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
}