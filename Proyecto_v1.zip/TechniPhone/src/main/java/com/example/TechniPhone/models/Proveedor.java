/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.TechniPhone.models;

import jakarta.persistence.Entity;
import jakarta.persistence.*;
import lombok.EqualsAndHashCode;

/**
 *
 * @author suria
 */
@Entity
@Table(name = "Proveedor")
@EqualsAndHashCode(callSuper = true)
public class Proveedor extends Persona {
    @Id
    @Column(name = "idProveedor")
    private int idProveedor;
    
    @Column(name = "nombreEmpresa", length = 100)
    private String nombreEmpresa;
    
    @Column(name = "nit", unique = true, length = 20)
    private String nit;

    public int getIdProveedor() {
        return idProveedor;
    }

    public void setIdProveedor(int idProveedor) {
        this.idProveedor = idProveedor;
    }

    public String getNombreEmpresa() {
        return nombreEmpresa;
    }

    public void setNombreEmpresa(String nombreEmpresa) {
        this.nombreEmpresa = nombreEmpresa;
    }

    public String getNit() {
        return nit;
    }

    public void setNit(String nit) {
        this.nit = nit;
    }
}