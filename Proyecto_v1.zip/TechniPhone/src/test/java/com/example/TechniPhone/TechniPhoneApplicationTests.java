package com.example.TechniPhone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechniPhoneApplicationTests {

	@Test
	void contextLoads() {
	}

}
