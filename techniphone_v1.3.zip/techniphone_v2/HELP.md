# TechniPhone — Sistema de Gestión

## Guía de referencia

### Tecnologías usadas
* [Spring Boot 4.0](https://spring.io/projects/spring-boot)
* [Spring Security](https://spring.io/projects/spring-security)
* [Spring Data JPA](https://spring.io/projects/spring-data-jpa)
* [Thymeleaf](https://www.thymeleaf.org/)
* [MySQL](https://www.mysql.com/)

### Requisitos
* Java 21
* Maven 3.8+
* MySQL 8+

### Configuración
1. Crear la base de datos: `CREATE DATABASE TECHNIPHONE_BD CHARACTER SET utf8mb4;`
2. Configurar credenciales en `src/main/resources/application.properties`
3. Ejecutar el SQL inicial para roles y usuario admin
4. Correr el proyecto con `mvn spring-boot:run`

### Credenciales por defecto
| Usuario | Contraseña | Rol |
|---|---|---|
| admin | admin123 | Administrador |
| vendedor | vendedor123 | Vendedor |
| tecnico | tecnico123 | Tecnico |

### Guías útiles
* [Documentación Spring Boot](https://docs.spring.io/spring-boot/docs/current/reference/htmlsingle/)
* [Guía de Spring Security](https://spring.io/guides/gs/securing-web/)
* [Guía de Thymeleaf](https://www.thymeleaf.org/documentation.html)
