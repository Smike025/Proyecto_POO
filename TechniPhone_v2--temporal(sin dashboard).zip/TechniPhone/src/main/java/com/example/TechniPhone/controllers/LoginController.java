/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.TechniPhone.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
/**
 *
 * @author suria
 */
@Controller
public class LoginController {

    // Esta es la ruta que te hace falta para que cargue el HTML
    @GetMapping("/login")
    public String verLogin() {
        return "login"; // Esto busca exactamente el archivo login.html en templates
    }

    // Por si queres probar el redireccionamiento despues del login
    @GetMapping("/inicio")
    public String verInicio() {
        return "index"; // O como se llame tu pagina de "Sistema en desarrollo"
    }
}