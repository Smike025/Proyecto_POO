/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.TechniPhone.models;

import jakarta.persistence.Column;
import jakarta.persistence.MappedSuperclass;

/**
 *
 * @author suria
 */
@MappedSuperclass
public abstract class Persona {
    
    
    @Column(name = "nombreCompleto", nullable = false, length = 100)
    private String nombreCompleto;
    
    @Column(name = "telefono", length = 15)
    private String telefono;

    // Agregamos el DUI que es vital para los empleados en El Salvador
    @Column(name = "dui", unique = true, length = 10)
    private String dui;

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getDui() {
        return dui;
    }

    public void setDui(String dui) {
        this.dui = dui;
    }
}