/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.example.TechniPhone.repository;

import com.example.TechniPhone.models.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;
/**
 *
 * @author suria
 */
@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Integer> {
    // Este método es vital: busca al usuario por nombre de acceso  
    Optional<Usuario> findByUsername(String username);
}