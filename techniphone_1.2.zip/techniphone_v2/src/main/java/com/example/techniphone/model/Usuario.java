package com.example.techniphone.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

@Entity
@Table(name = "usuarios")
public class Usuario extends Persona implements UserDetails {

    @Column(nullable = false, unique = true, length = 80)
    private String username;

    @Column(nullable = false)
    private String password;

    @Column(nullable = false)
    private Integer nivelAcceso = 1;

    @Column(nullable = false)
    private Boolean habilitado = true;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
        name = "usuario_roles",
        joinColumns = @JoinColumn(name = "usuario_id"),
        inverseJoinColumns = @JoinColumn(name = "rol_id")
    )
    private Set<Rol> roles = new HashSet<>();

    // Constructores
    public Usuario() { super(); }

    public Usuario(String nombre, String telefono, String username, String password) {
        super(null, nombre, telefono);
        this.username = username;
        this.password = password;
    }

    // Metodo polimorfico
    @Override
    public String mostrarDetalles() {
        return "Usuario: " + getNombre() + " | Acceso nivel: " + nivelAcceso;
    }

    // Metodos de negocio
    public void login() { this.habilitado = true; }

    public void cambiarPassword(String nuevoPassword) {
        this.password = nuevoPassword;
    }

    // ── UserDetails (requeridos por Spring Security) ──────────
    @Override
    public String getUsername() { return username; }

    @Override
    public String getPassword() { return password; }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return roles.stream()
                .map(r -> new SimpleGrantedAuthority(r.getNombreRol()))
                .collect(Collectors.toList());
    }

    @Override public boolean isAccountNonExpired()     { return true; }
    @Override public boolean isAccountNonLocked()      { return true; }
    @Override public boolean isCredentialsNonExpired() { return true; }
    @Override public boolean isEnabled()               { return habilitado; }

    // Getters y Setters propios
    public void setUsername(String username) { this.username = username; }
    public void setPassword(String password) { this.password = password; }

    public Integer getNivelAcceso() { return nivelAcceso; }
    public void setNivelAcceso(Integer nivelAcceso) { this.nivelAcceso = nivelAcceso; }

    public Boolean getHabilitado() { return habilitado; }
    public void setHabilitado(Boolean habilitado) { this.habilitado = habilitado; }

    public Set<Rol> getRoles() { return roles; }
    public void setRoles(Set<Rol> roles) { this.roles = roles; }
}
