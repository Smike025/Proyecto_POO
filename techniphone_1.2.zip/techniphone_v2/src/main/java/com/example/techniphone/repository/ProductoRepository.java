package com.example.techniphone.repository;

import com.example.techniphone.model.Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ProductoRepository extends JpaRepository<Producto, Long> {
    List<Producto> findByNombreContainingIgnoreCase(String nombre);
    List<Producto> findByStockLessThan(int cantidad);
    List<Producto> findByCategoriaId(Long categoriaId);
}
