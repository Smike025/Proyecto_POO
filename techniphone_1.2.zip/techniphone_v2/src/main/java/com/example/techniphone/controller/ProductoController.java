package com.example.techniphone.controller;

import com.example.techniphone.model.Producto;
import com.example.techniphone.repository.CategoriaRepository;
import com.example.techniphone.repository.ProveedorRepository;
import com.example.techniphone.service.ProductoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/productos")
public class ProductoController {

    private final ProductoService productoService;
    private final CategoriaRepository categoriaRepo;
    private final ProveedorRepository proveedorRepo;

    public ProductoController(ProductoService productoService,
                              CategoriaRepository categoriaRepo,
                              ProveedorRepository proveedorRepo) {
        this.productoService = productoService;
        this.categoriaRepo   = categoriaRepo;
        this.proveedorRepo   = proveedorRepo;
    }

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("productos", productoService.listarTodos());
        model.addAttribute("stockBajo", productoService.productosConStockBajo());
        return "productos/lista";
    }

    @GetMapping("/nuevo")
    public String formularioNuevo(Model model) {
        model.addAttribute("producto",    new Producto());
        model.addAttribute("categorias",  categoriaRepo.findAll());
        model.addAttribute("proveedores", proveedorRepo.findAll());
        return "productos/formulario";
    }

    @PostMapping("/guardar")
    public String guardar(@ModelAttribute Producto producto, RedirectAttributes flash) {
        try {
            productoService.guardar(producto);
            flash.addFlashAttribute("exito", "Producto guardado correctamente.");
        } catch (Exception e) {
            flash.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/productos";
    }

    @GetMapping("/editar/{id}")
    public String formularioEditar(@PathVariable Long id, Model model) {
        model.addAttribute("producto",    productoService.buscarPorId(id));
        model.addAttribute("categorias",  categoriaRepo.findAll());
        model.addAttribute("proveedores", proveedorRepo.findAll());
        return "productos/formulario";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id, RedirectAttributes flash) {
        try {
            productoService.eliminar(id);
            flash.addFlashAttribute("exito", "Producto eliminado.");
        } catch (Exception e) {
            flash.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/productos";
    }
}
