package com.example.techniphone.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "proveedores")
public class Proveedor extends Persona {

    @Column(length = 150)
    private String nombreEmpresa;

    @Column(length = 20)
    private String nit;

    // Constructores
    public Proveedor() { super(); }

    public Proveedor(String nombre, String telefono, String nombreEmpresa, String nit) {
        super(null, nombre, telefono);
        this.nombreEmpresa = nombreEmpresa;
        this.nit = nit;
    }

    // Metodo polimorfico
    @Override
    public String mostrarDetalles() {
        return "Proveedor: " + nombreEmpresa + " | NIT: " + nit;
    }

    // Getters y Setters
    public String getNombreEmpresa() { return nombreEmpresa; }
    public void setNombreEmpresa(String nombreEmpresa) { this.nombreEmpresa = nombreEmpresa; }

    public String getNit() { return nit; }
    public void setNit(String nit) { this.nit = nit; }
}
