package com.example.techniphone.repository;

import com.example.techniphone.model.Reparacion;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ReparacionRepository extends JpaRepository<Reparacion, Long> {
    List<Reparacion> findByEstado(Reparacion.Estado estado);
    List<Reparacion> findByClienteId(Long clienteId);
}
