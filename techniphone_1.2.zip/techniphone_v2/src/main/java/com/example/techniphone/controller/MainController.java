package com.example.techniphone.controller;

import com.example.techniphone.repository.ClienteRepository;
import com.example.techniphone.repository.ProductoRepository;
import com.example.techniphone.repository.ReparacionRepository;
import com.example.techniphone.repository.VentaRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {

    private final ProductoRepository productoRepo;
    private final ClienteRepository clienteRepo;
    private final ReparacionRepository reparacionRepo;
    private final VentaRepository ventaRepo;

    public MainController(ProductoRepository productoRepo,
                          ClienteRepository clienteRepo,
                          ReparacionRepository reparacionRepo,
                          VentaRepository ventaRepo) {
        this.productoRepo    = productoRepo;
        this.clienteRepo     = clienteRepo;
        this.reparacionRepo  = reparacionRepo;
        this.ventaRepo       = ventaRepo;
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping({"/", "/inicio"})
    public String inicio(Model model) {
        model.addAttribute("totalProductos",    productoRepo.count());
        model.addAttribute("totalClientes",     clienteRepo.count());
        model.addAttribute("totalReparaciones", reparacionRepo.count());
        model.addAttribute("totalVentas",       ventaRepo.count());
        model.addAttribute("reparacionesRecientes",
                reparacionRepo.findAll().stream().limit(5).toList());
        return "index";
    }
}
