package com.example.techniphone.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "clientes")
public class Cliente extends Persona {

    @Column(length = 10)
    private String dui;

    @Column(length = 255)
    private String direccion;

    // Constructores
    public Cliente() { super(); }

    public Cliente(String nombre, String telefono, String dui, String direccion) {
        super(null, nombre, telefono);
        this.dui = dui;
        this.direccion = direccion;
    }

    // Metodo polimorfico
    @Override
    public String mostrarDetalles() {
        return "Cliente: " + getNombre() + " | DUI: " + dui + " | Tel: " + getTelefono();
    }

    // Getters y Setters
    public String getDui() { return dui; }
    public void setDui(String dui) { this.dui = dui; }

    public String getDireccion() { return direccion; }
    public void setDireccion(String direccion) { this.direccion = direccion; }
}
