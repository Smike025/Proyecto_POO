package com.example.techniphone.service;

import com.example.techniphone.exception.ResourceNotFoundException;
import com.example.techniphone.model.Cliente;
import com.example.techniphone.repository.ClienteRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@Transactional
public class ClienteService {

    private final ClienteRepository clienteRepository;

    public ClienteService(ClienteRepository clienteRepository) {
        this.clienteRepository = clienteRepository;
    }

    public List<Cliente> listarTodos() {
        return clienteRepository.findAll();
    }

    public Cliente buscarPorId(Long id) {
        return clienteRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Cliente", id));
    }

    public Cliente guardar(Cliente cliente) {
        if (cliente.getId() == null && clienteRepository.existsByDui(cliente.getDui())) {
            throw new IllegalStateException("Ya existe un cliente con el DUI: " + cliente.getDui());
        }
        return clienteRepository.save(cliente);
    }

    public Cliente actualizar(Long id, Cliente datos) {
        Cliente c = buscarPorId(id);
        c.setNombre(datos.getNombre());
        c.setTelefono(datos.getTelefono());
        c.setDui(datos.getDui());
        c.setDireccion(datos.getDireccion());
        return clienteRepository.save(c);
    }

    public void eliminar(Long id) {
        clienteRepository.delete(buscarPorId(id));
    }
}
