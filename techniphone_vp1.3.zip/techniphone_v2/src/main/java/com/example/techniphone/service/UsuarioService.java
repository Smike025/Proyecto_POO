/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.techniphone.service;

import com.example.techniphone.exception.ResourceNotFoundException;
import com.example.techniphone.model.Rol;
import com.example.techniphone.model.Usuario;
import com.example.techniphone.repository.RolRepository;
import com.example.techniphone.repository.UsuarioRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 *
 * @author suria
 */
@Service
@Transactional
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;
    private final RolRepository rolRepository;

    public UsuarioService(UsuarioRepository usuarioRepository,
                          RolRepository rolRepository) {
        this.usuarioRepository = usuarioRepository;
        this.rolRepository     = rolRepository;
    }

    public List<Usuario> listarTodos() {
        return usuarioRepository.findAll();
    }

    public Usuario buscarPorId(Long id) {
        return usuarioRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Usuario", id));
    }

    public List<Rol> listarRoles() {
        return rolRepository.findAll();
    }

    public Usuario guardar(Usuario usuario, Long rolId) {
        if (rolId != null) {
            Rol rol = rolRepository.findById(rolId)
                    .orElseThrow(() -> new ResourceNotFoundException("Rol", rolId));
            Set<Rol> roles = new HashSet<>();
            roles.add(rol);
            usuario.setRoles(roles);
        }
        return usuarioRepository.save(usuario);
    }

    public Usuario actualizar(Long id, Usuario datos, Long rolId) {
        Usuario u = buscarPorId(id);
        u.setNombre(datos.getNombre());
        u.setTelefono(datos.getTelefono());
        u.setUsername(datos.getUsername());
        u.setEspecialidad(datos.getEspecialidad());
        u.setTurno(datos.getTurno());
        u.setHabilitado(datos.getHabilitado());
        if (datos.getPassword() != null && !datos.getPassword().isBlank()) {
            u.setPassword(datos.getPassword());
        }
        if (rolId != null) {
            Rol rol = rolRepository.findById(rolId)
                    .orElseThrow(() -> new ResourceNotFoundException("Rol", rolId));
            Set<Rol> roles = new HashSet<>();
            roles.add(rol);
            u.setRoles(roles);
        }
        return usuarioRepository.save(u);
    }

    public void eliminar(Long id) {
        usuarioRepository.delete(buscarPorId(id));
    }
}