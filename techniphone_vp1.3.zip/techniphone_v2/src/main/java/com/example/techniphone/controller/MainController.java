/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.techniphone.controller;

import com.example.techniphone.model.Reparacion;
import com.example.techniphone.model.Venta;
import com.example.techniphone.repository.ClienteRepository;
import com.example.techniphone.repository.ProductoRepository;
import com.example.techniphone.repository.ReparacionRepository;
import com.example.techniphone.repository.VentaRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/**
 *
 * @author suria
 */
@Controller
public class MainController {

    private final ProductoRepository   productoRepo;
    private final ClienteRepository    clienteRepo;
    private final ReparacionRepository reparacionRepo;
    private final VentaRepository      ventaRepo;

    public MainController(ProductoRepository productoRepo,
                          ClienteRepository clienteRepo,
                          ReparacionRepository reparacionRepo,
                          VentaRepository ventaRepo) {
        this.productoRepo   = productoRepo;
        this.clienteRepo    = clienteRepo;
        this.reparacionRepo = reparacionRepo;
        this.ventaRepo      = ventaRepo;
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping({"/", "/inicio"})
    public String inicio(Model model) {

        List<Venta>      todasVentas  = ventaRepo.findAll();
        List<Reparacion> reparaciones = reparacionRepo.findAll();

        // ── Ventas de hoy ─────────────────────────────────────
        double ventasHoy = todasVentas.stream()
                .filter(v -> v.getFechaVenta() != null &&
                             v.getFechaVenta().toLocalDate().equals(LocalDate.now()))
                .mapToDouble(v -> v.getTotal() != null ? v.getTotal() : 0)
                .sum();

        // ── Ventas recientes (últimas 5) ──────────────────────
        List<Venta> ventasRecientes = todasVentas.stream()
                .sorted(Comparator.comparing(
                        v -> v.getFechaVenta() != null ? v.getFechaVenta() : LocalDateTime.MIN,
                        Comparator.reverseOrder()))
                .limit(5)
                .collect(Collectors.toList());

        // ── Reparaciones activas ──────────────────────────────
        List<Reparacion> reparacionesActivas = reparaciones.stream()
                .filter(r -> r.getEstado() == Reparacion.Estado.RECIBIDO ||
                             r.getEstado() == Reparacion.Estado.EN_PROCESO)
                .sorted(Comparator.comparing(
                        r -> r.getFechaIngreso() != null ? r.getFechaIngreso() : LocalDateTime.MIN,
                        Comparator.reverseOrder()))
                .limit(5)
                .collect(Collectors.toList());

        // ── KPIs ──────────────────────────────────────────────
        model.addAttribute("totalProductos",        productoRepo.count());
        model.addAttribute("totalClientes",         clienteRepo.count());
        model.addAttribute("totalReparaciones",     reparacionesActivas.size());
        model.addAttribute("totalVentas",           todasVentas.size());
        model.addAttribute("ventasHoy",             ventasHoy);
        model.addAttribute("ventasRecientes",       ventasRecientes);
        model.addAttribute("reparacionesRecientes", reparacionesActivas);

        return "index";
    }

    @GetMapping("/acceso-denegado")
    public String accesoDenegado() {
        return "error/acceso-denegado";
    }
}