/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.techniphone.controller;

import com.example.techniphone.model.Venta;
import com.example.techniphone.repository.ClienteRepository;
import com.example.techniphone.repository.ProductoRepository;
import com.example.techniphone.repository.UsuarioRepository;
import com.example.techniphone.repository.VentaRepository;
import com.example.techniphone.service.VentaService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author suria
 */
@Controller
@RequestMapping("/ventas")
public class VentaController {

    private final VentaRepository    ventaRepo;
    private final ClienteRepository  clienteRepo;
    private final UsuarioRepository  usuarioRepo;
    private final ProductoRepository productoRepo;
    private final VentaService       ventaService;

    public VentaController(VentaRepository ventaRepo,
                           ClienteRepository clienteRepo,
                           UsuarioRepository usuarioRepo,
                           ProductoRepository productoRepo,
                           VentaService ventaService) {
        this.ventaRepo    = ventaRepo;
        this.clienteRepo  = clienteRepo;
        this.usuarioRepo  = usuarioRepo;
        this.productoRepo = productoRepo;
        this.ventaService = ventaService;
    }

    // ── Lista ─────────────────────────────────────────────────
    @GetMapping
    public String lista(Model model) {
        List<Venta> ventas = ventaRepo.findAll();

        double totalHoy = ventas.stream()
                .filter(v -> v.getFechaVenta() != null &&
                             v.getFechaVenta().toLocalDate().equals(LocalDate.now()))
                .mapToDouble(v -> v.getTotal() != null ? v.getTotal() : 0)
                .sum();

        int totalProductosVendidos = ventas.stream()
                .flatMap(v -> v.getDetalles().stream())
                .mapToInt(d -> d.getCantidad() != null ? d.getCantidad() : 0)
                .sum();

        model.addAttribute("ventas",                 ventas);
        model.addAttribute("total",                  ventas.size());
        model.addAttribute("totalHoy",               totalHoy);
        model.addAttribute("totalProductosVendidos", totalProductosVendidos);
        return "ventas/lista";
    }

    // ── Formulario nueva venta ────────────────────────────────
    @GetMapping("/nueva")
    public String nueva(Model model) {
        model.addAttribute("venta",     new Venta());
        model.addAttribute("clientes",  clienteRepo.findAll());
        model.addAttribute("usuarios",  usuarioRepo.findAll());
        model.addAttribute("productos", productoRepo.findAll());
        return "ventas/formulario";
    }

    // ── Guardar venta ─────────────────────────────────────────
    @PostMapping("/guardar")
    public String guardar(@ModelAttribute Venta venta,
                          @RequestParam(value = "productoIds", required = false) List<Long>    productoIds,
                          @RequestParam(value = "cantidades",  required = false) List<Integer> cantidades,
                          @RequestParam(value = "precios",     required = false) List<Double>  precios,
                          RedirectAttributes ra) {
        try {
            // Resolver cliente
            if (venta.getCliente() != null && venta.getCliente().getId() != null) {
                clienteRepo.findById(venta.getCliente().getId())
                           .ifPresent(venta::setCliente);
            } else {
                venta.setCliente(null);
            }

            // Resolver usuario/vendedor
            if (venta.getUsuario() != null && venta.getUsuario().getId() != null) {
                usuarioRepo.findById(venta.getUsuario().getId())
                           .ifPresent(venta::setUsuario);
            } else {
                venta.setUsuario(null);
            }

            // Fecha
            venta.setFechaVenta(java.time.LocalDateTime.now());

            // Llamar al método correcto del service
            ventaService.guardar(venta, productoIds, cantidades, precios);
            ra.addFlashAttribute("exito", "Venta registrada correctamente.");
        } catch (IllegalStateException e) {
            ra.addFlashAttribute("error", e.getMessage());
        } catch (Exception e) {
            ra.addFlashAttribute("error", "Error al registrar la venta: " + e.getMessage());
        }
        return "redirect:/ventas";
    }

    // ── Ver detalle ───────────────────────────────────────────
    @GetMapping("/ver/{id}")
    public String ver(@PathVariable Long id, Model model, RedirectAttributes ra) {
        Optional<Venta> opt = ventaRepo.findById(id);
        if (opt.isEmpty()) {
            ra.addFlashAttribute("error", "Venta no encontrada.");
            return "redirect:/ventas";
        }
        model.addAttribute("venta", opt.get());
        return "ventas/detalle";
    }

    // ── Eliminar ──────────────────────────────────────────────
    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id, RedirectAttributes ra) {
        try {
            ventaService.eliminar(id);
            ra.addFlashAttribute("exito", "Venta eliminada correctamente.");
        } catch (Exception e) {
            ra.addFlashAttribute("error", "No se pudo eliminar la venta.");
        }
        return "redirect:/ventas";
    }
}