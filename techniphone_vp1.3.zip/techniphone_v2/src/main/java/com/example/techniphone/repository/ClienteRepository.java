/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.example.techniphone.repository;

import com.example.techniphone.model.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

/**
 *
 * @author suria
 */
public interface ClienteRepository extends JpaRepository<Cliente, Long> {
    List<Cliente> findByNombreContainingIgnoreCase(String nombre);
    boolean existsByDui(String dui);
}
