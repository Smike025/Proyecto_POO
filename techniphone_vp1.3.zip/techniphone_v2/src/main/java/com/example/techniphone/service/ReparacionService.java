/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.example.techniphone.service;

import com.example.techniphone.exception.ResourceNotFoundException;
import com.example.techniphone.model.Reparacion;
import com.example.techniphone.repository.ReparacionRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

/**
 *
 * @author suria
 */
@Service
@Transactional
public class ReparacionService {

    private final ReparacionRepository reparacionRepository;

    public ReparacionService(ReparacionRepository reparacionRepository) {
        this.reparacionRepository = reparacionRepository;
    }

    public List<Reparacion> listarTodas() {
        return reparacionRepository.findAll();
    }

    public Reparacion buscarPorId(Long id) {
        return reparacionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Reparacion", id));
    }

    public Reparacion guardar(Reparacion rep) {
        return reparacionRepository.save(rep);
    }

    public Reparacion cambiarEstado(Long id, Reparacion.Estado nuevoEstado) {
        Reparacion rep = buscarPorId(id);
        rep.setEstado(nuevoEstado);
        return reparacionRepository.save(rep);
    }

    public void eliminar(Long id) {
        reparacionRepository.delete(buscarPorId(id));
    }
}
