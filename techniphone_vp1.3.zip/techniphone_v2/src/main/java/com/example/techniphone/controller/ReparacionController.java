/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.techniphone.controller;

import com.example.techniphone.model.Reparacion;
import com.example.techniphone.repository.ClienteRepository;
import com.example.techniphone.repository.UsuarioRepository;
import com.example.techniphone.service.ReparacionService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 *
 * @author suria
 */
@Controller
@RequestMapping("/reparaciones")
public class ReparacionController {

    private final ReparacionService reparacionService;
    private final ClienteRepository clienteRepo;
    private final UsuarioRepository usuarioRepo;

    public ReparacionController(ReparacionService reparacionService,
                                ClienteRepository clienteRepo,
                                UsuarioRepository usuarioRepo) {
        this.reparacionService = reparacionService;
        this.clienteRepo       = clienteRepo;
        this.usuarioRepo       = usuarioRepo;
    }

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("reparaciones", reparacionService.listarTodas());
        model.addAttribute("estados",      Reparacion.Estado.values());
        return "reparaciones/lista";
    }

    @GetMapping("/nueva")
    public String formulario(Model model) {
        model.addAttribute("reparacion", new Reparacion());
        model.addAttribute("clientes",   clienteRepo.findAll());
        model.addAttribute("tecnicos",   usuarioRepo.findAll());
        model.addAttribute("estados",    Reparacion.Estado.values());
        return "reparaciones/formulario";
    }

    @PostMapping("/guardar")
    public String guardar(@ModelAttribute Reparacion reparacion,
                          RedirectAttributes flash) {
        try {
            reparacionService.guardar(reparacion);
            flash.addFlashAttribute("exito", "Reparacion registrada.");
        } catch (Exception e) {
            flash.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/reparaciones";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model) {
        model.addAttribute("reparacion", reparacionService.buscarPorId(id));
        model.addAttribute("clientes",   clienteRepo.findAll());
        model.addAttribute("tecnicos",   usuarioRepo.findAll());
        model.addAttribute("estados",    Reparacion.Estado.values());
        return "reparaciones/formulario";
    }

    // ← ESTE FALTABA
    @PostMapping("/editar/{id}")
    public String actualizar(@PathVariable Long id,
                             @ModelAttribute Reparacion datos,
                             RedirectAttributes flash) {
        try {
            Reparacion existente = reparacionService.buscarPorId(id);
            existente.setModeloCelular(datos.getModeloCelular());
            existente.setDescripcionProblema(datos.getDescripcionProblema());
            existente.setObservaciones(datos.getObservaciones());
            existente.setCostoEstimado(datos.getCostoEstimado());
            existente.setEstado(datos.getEstado());
            existente.setCliente(datos.getCliente());
            existente.setTecnico(datos.getTecnico());
            reparacionService.guardar(existente);
            flash.addFlashAttribute("exito", "Reparacion actualizada correctamente.");
        } catch (Exception e) {
            flash.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/reparaciones";
    }

    @PostMapping("/estado/{id}")
    public String cambiarEstado(@PathVariable Long id,
                                @RequestParam Reparacion.Estado estado,
                                RedirectAttributes flash) {
        try {
            reparacionService.cambiarEstado(id, estado);
            flash.addFlashAttribute("exito", "Estado actualizado.");
        } catch (Exception e) {
            flash.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/reparaciones";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id, RedirectAttributes flash) {
        try {
            reparacionService.eliminar(id);
            flash.addFlashAttribute("exito", "Reparacion eliminada.");
        } catch (Exception e) {
            flash.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/reparaciones";
    }
}