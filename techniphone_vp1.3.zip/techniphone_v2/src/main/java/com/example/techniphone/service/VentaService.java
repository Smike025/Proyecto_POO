/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.techniphone.service;

import com.example.techniphone.exception.ResourceNotFoundException;
import com.example.techniphone.model.DetalleVenta;
import com.example.techniphone.model.Producto;
import com.example.techniphone.model.Venta;
import com.example.techniphone.repository.ProductoRepository;
import com.example.techniphone.repository.VentaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
/**
 *
 * @author suria
 */
@Service
@Transactional
public class VentaService {

    private final VentaRepository ventaRepository;
    private final ProductoRepository productoRepository;

    public VentaService(VentaRepository ventaRepository,
                        ProductoRepository productoRepository) {
        this.ventaRepository    = ventaRepository;
        this.productoRepository = productoRepository;
    }

    public List<Venta> listarTodas() {
        return ventaRepository.findAll();
    }

    public Venta buscarPorId(Long id) {
        return ventaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Venta", id));
    }

    public Venta guardar(Venta venta, List<Long> productoIds,
                         List<Integer> cantidades, List<Double> precios) {

        venta.getDetalles().clear();

        if (productoIds != null) {
            for (int i = 0; i < productoIds.size(); i++) {
                Long pid = productoIds.get(i);
                if (pid == null) continue;

                Producto p = productoRepository.findById(pid)
                        .orElseThrow(() -> new ResourceNotFoundException("Producto", pid));

                int cantidad = cantidades.get(i);
                double precio = precios.get(i);

                if (cantidad > p.getStock()) {
                    throw new IllegalStateException(
                        "Stock insuficiente para: " + p.getNombre()
                        + " (disponible: " + p.getStock() + ")");
                }

                p.reducirStock(cantidad);
                productoRepository.save(p);

                DetalleVenta det = new DetalleVenta();
                det.setProducto(p);
                det.setCantidad(cantidad);
                det.setPrecioUnitario(precio);
                det.setSubtotal(cantidad * precio);
                det.setVenta(venta);
                venta.getDetalles().add(det);
            }
        }

        venta.calcularTotal();
        return ventaRepository.save(venta);
    }

    public void eliminar(Long id) {
        ventaRepository.delete(buscarPorId(id));
    }

    public double totalVentasHoy() {
        return ventaRepository.findAll().stream()
                .filter(v -> v.getFechaVenta() != null &&
                             v.getFechaVenta().toLocalDate()
                              .equals(java.time.LocalDate.now()))
                .mapToDouble(v -> v.getTotal() != null ? v.getTotal() : 0.0)
                .sum();
    }
}