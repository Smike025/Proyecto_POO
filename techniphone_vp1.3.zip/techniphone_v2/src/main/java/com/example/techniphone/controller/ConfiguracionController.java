/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.techniphone.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author suria
 */
@Controller
@RequestMapping("/configuracion")
public class ConfiguracionController {

    @GetMapping
    public String index(Model model) {
        model.addAttribute("fecha", LocalDate.now()
                .format(DateTimeFormatter.ofPattern("d/M/yyyy")));
        return "configuracion/index";
    }

    @PostMapping("/negocio")
    public String guardarNegocio(
            @RequestParam String nombreNegocio,
            @RequestParam(required = false) String telefono,
            @RequestParam(required = false) String nit,
            @RequestParam(required = false) String nrc,
            RedirectAttributes flash) {
        flash.addFlashAttribute("exitoNegocio", "Datos del negocio guardados correctamente.");
        return "redirect:/configuracion";
    }

    @PostMapping("/dte")
    public String guardarDte(
            @RequestParam(required = false) String ambienteDte,
            @RequestParam(required = false) String claveDte,
            @RequestParam(required = false) String envioAutomatico,
            RedirectAttributes flash) {
        flash.addFlashAttribute("exitoDte", "Configuracion DTE guardada.");
        return "redirect:/configuracion";
    }

    @PostMapping("/notificaciones")
    public String guardarNotificaciones(
            @RequestParam(required = false) String alertaStock,
            @RequestParam(required = false) String alertaReparaciones,
            @RequestParam(required = false) String resumenDiario,
            RedirectAttributes flash) {
        flash.addFlashAttribute("exitoNoti", "Preferencias de notificaciones guardadas.");
        return "redirect:/configuracion";
    }
}