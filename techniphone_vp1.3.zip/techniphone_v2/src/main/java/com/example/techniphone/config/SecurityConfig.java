/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.techniphone.config;

import com.example.techniphone.service.UserDetailsServiceImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

/**
 *
 * @author suria
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private final UserDetailsServiceImpl userDetailsService;

    public SecurityConfig(UserDetailsServiceImpl userDetailsService) {
        this.userDetailsService = userDetailsService;
    }

    @Bean
    @SuppressWarnings("deprecation")
    public PasswordEncoder passwordEncoder() {
        return NoOpPasswordEncoder.getInstance();
    }

    @Bean
    public AuthenticationManager authenticationManager(HttpSecurity http) throws Exception {
        AuthenticationManagerBuilder builder =
                http.getSharedObject(AuthenticationManagerBuilder.class);
        builder.userDetailsService(userDetailsService)
               .passwordEncoder(passwordEncoder());
        return builder.build();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests(auth -> auth

                // ── Públicos ──────────────────────────────────
                .requestMatchers("/css/**", "/js/**", "/img/**").permitAll()
                .requestMatchers("/login").permitAll()

                // ── Solo ADMIN ────────────────────────────────
                .requestMatchers("/proveedores/**").hasRole("ADMIN")
                .requestMatchers("/usuarios/**").hasRole("ADMIN")
                .requestMatchers("/reportes/**").hasRole("ADMIN")
                .requestMatchers("/configuracion/**").hasRole("ADMIN")

                // ── Ventas: solo ADMIN y USER (vendedor) ──────
                .requestMatchers("/ventas/**").hasAnyRole("ADMIN", "USER")

                // ── Clientes: escritura solo ADMIN y USER ─────
                .requestMatchers("/clientes/nuevo",
                                 "/clientes/guardar",
                                 "/clientes/editar/**",
                                 "/clientes/actualizar/**",
                                 "/clientes/eliminar/**").hasAnyRole("ADMIN", "USER")
                .requestMatchers("/clientes/**").hasAnyRole("ADMIN", "USER", "TECNICO")

                // ── Inventario: escritura solo ADMIN ──────────
                .requestMatchers("/productos/nuevo",
                                 "/productos/guardar",
                                 "/productos/editar/**",
                                 "/productos/eliminar/**").hasRole("ADMIN")
                .requestMatchers("/productos/**").hasAnyRole("ADMIN", "USER", "TECNICO")

                // ── Reparaciones: todos acceden ───────────────
                .requestMatchers("/reparaciones/**").hasAnyRole("ADMIN", "USER", "TECNICO")

                // ── Dashboard: todos acceden ──────────────────
                .requestMatchers("/inicio", "/").hasAnyRole("ADMIN", "USER", "TECNICO")

                // ── Resto requiere autenticacion ──────────────
                .anyRequest().authenticated()
            )
            .formLogin(form -> form
                .loginPage("/login")
                .loginProcessingUrl("/login")
                .defaultSuccessUrl("/inicio", true)
                .failureUrl("/login?error=true")
                .permitAll()
            )
            .logout(logout -> logout
                .logoutUrl("/logout")
                .logoutSuccessUrl("/login?logout=true")
                .permitAll()
            )
            .exceptionHandling(ex -> ex
                .accessDeniedPage("/acceso-denegado")
            );

        return http.build();
    }
}