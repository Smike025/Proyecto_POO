/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

/**
 *
 * @author suria
 */
package com.example.techniphone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TechniPhoneApplication {

    public static void main(String[] args) {
        SpringApplication.run(TechniPhoneApplication.class, args);
    }
}
