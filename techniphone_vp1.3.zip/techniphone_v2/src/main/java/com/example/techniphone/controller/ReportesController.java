/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.techniphone.controller;

import com.example.techniphone.model.Reparacion;
import com.example.techniphone.model.Venta;
import com.example.techniphone.repository.ClienteRepository;
import com.example.techniphone.repository.ProductoRepository;
import com.example.techniphone.repository.ReparacionRepository;
import com.example.techniphone.repository.VentaRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.TextStyle;
import java.util.*;
import java.util.stream.Collectors;
/**
 *
 * @author suria
 */
@Controller
@RequestMapping("/reportes")
public class ReportesController {

    private final VentaRepository      ventaRepo;
    private final ReparacionRepository reparacionRepo;
    private final ProductoRepository   productoRepo;
    private final ClienteRepository    clienteRepo;

    public ReportesController(VentaRepository ventaRepo,
                               ReparacionRepository reparacionRepo,
                               ProductoRepository productoRepo,
                               ClienteRepository clienteRepo) {
        this.ventaRepo      = ventaRepo;
        this.reparacionRepo = reparacionRepo;
        this.productoRepo   = productoRepo;
        this.clienteRepo    = clienteRepo;
    }

    @GetMapping
    public String index(@RequestParam(defaultValue = "hoy") String periodo,
                        Model model) {

        List<Venta>      todasVentas  = ventaRepo.findAll();
        List<Reparacion> reparaciones = reparacionRepo.findAll();

        // ── Rango de fechas según periodo ─────────────────────────
        LocalDate hoy   = LocalDate.now();
        LocalDate desde;
        LocalDate hasta;

        switch (periodo) {
            case "ayer"     -> { desde = hoy.minusDays(1);  hasta = hoy.minusDays(1); }
            case "semana"   -> { desde = hoy.minusWeeks(1); hasta = hoy; }
            case "mes"      -> { desde = hoy.minusMonths(1);hasta = hoy; }
            case "semestre" -> { desde = hoy.minusMonths(6);hasta = hoy; }
            case "anio"     -> { desde = hoy.minusYears(1); hasta = hoy; }
            default         -> { desde = hoy;                hasta = hoy; } // "hoy"
        }

        final LocalDate desdeF = desde;
        final LocalDate hastaF = hasta;

        // ── Ventas filtradas por periodo ──────────────────────────
        List<Venta> ventas = todasVentas.stream()
                .filter(v -> v.getFechaVenta() != null &&
                             !v.getFechaVenta().toLocalDate().isBefore(desdeF) &&
                             !v.getFechaVenta().toLocalDate().isAfter(hastaF))
                .collect(Collectors.toList());

        // ── Totales ───────────────────────────────────────────────
        double totalIngresos = ventas.stream()
                .mapToDouble(v -> v.getTotal() != null ? v.getTotal() : 0)
                .sum();

        double ingresosHoy = todasVentas.stream()
                .filter(v -> v.getFechaVenta() != null &&
                             v.getFechaVenta().toLocalDate().equals(hoy))
                .mapToDouble(v -> v.getTotal() != null ? v.getTotal() : 0)
                .sum();

        long reparacionesActivas = reparaciones.stream()
                .filter(r -> r.getEstado() == Reparacion.Estado.RECIBIDO ||
                             r.getEstado() == Reparacion.Estado.EN_PROCESO)
                .count();

        // ── Etiqueta legible del periodo ──────────────────────────
        String periodoLabel = switch (periodo) {
            case "ayer"     -> "Ayer";
            case "semana"   -> "Ultima semana";
            case "mes"      -> "Ultimo mes";
            case "semestre" -> "Ultimos 6 meses";
            case "anio"     -> "Este ano";
            default         -> "Hoy";
        };

        model.addAttribute("periodo",             periodo);
        model.addAttribute("periodoLabel",        periodoLabel);
        model.addAttribute("totalIngresos",       totalIngresos);
        model.addAttribute("ingresosHoy",         ingresosHoy);
        model.addAttribute("totalVentas",         ventas.size());
        model.addAttribute("totalReparaciones",   reparaciones.size());
        model.addAttribute("reparacionesActivas", reparacionesActivas);
        model.addAttribute("totalClientes",       clienteRepo.count());
        model.addAttribute("totalProductos",      productoRepo.count());
        model.addAttribute("stockBajo",           productoRepo.findByStockLessThan(5).size());

        // ── Puntos del gráfico según periodo ─────────────────────
        List<String> grafLabels  = new ArrayList<>();
        List<Double> grafTotales = new ArrayList<>();

        if (periodo.equals("hoy")) {
            for (int h = 0; h < 24; h++) {
                final int hora = h;
                grafLabels.add(String.format("%02d:00", h));
                double sum = ventas.stream()
                        .filter(v -> v.getFechaVenta() != null &&
                                     v.getFechaVenta().toLocalDate().equals(hoy) &&
                                     v.getFechaVenta().getHour() == hora)
                        .mapToDouble(v -> v.getTotal() != null ? v.getTotal() : 0)
                        .sum();
                grafTotales.add(Math.round(sum * 100.0) / 100.0);
            }
        } else if (periodo.equals("ayer")) {
            LocalDate ayer = hoy.minusDays(1);
            for (int h = 0; h < 24; h++) {
                final int hora = h;
                grafLabels.add(String.format("%02d:00", h));
                double sum = ventas.stream()
                        .filter(v -> v.getFechaVenta() != null &&
                                     v.getFechaVenta().toLocalDate().equals(ayer) &&
                                     v.getFechaVenta().getHour() == hora)
                        .mapToDouble(v -> v.getTotal() != null ? v.getTotal() : 0)
                        .sum();
                grafTotales.add(Math.round(sum * 100.0) / 100.0);
            }
        } else if (periodo.equals("semana")) {
            for (int d = 6; d >= 0; d--) {
                LocalDate dia = hoy.minusDays(d);
                String lbl = dia.getDayOfWeek()
                        .getDisplayName(TextStyle.SHORT, new Locale("es", "SV"));
                grafLabels.add(lbl);
                double sum = ventas.stream()
                        .filter(v -> v.getFechaVenta() != null &&
                                     v.getFechaVenta().toLocalDate().equals(dia))
                        .mapToDouble(v -> v.getTotal() != null ? v.getTotal() : 0)
                        .sum();
                grafTotales.add(Math.round(sum * 100.0) / 100.0);
            }
        } else if (periodo.equals("mes")) {
            for (int w = 3; w >= 0; w--) {
                LocalDate ini = hoy.minusWeeks(w + 1).plusDays(1);
                LocalDate fin = hoy.minusWeeks(w);
                grafLabels.add("Sem " + (4 - w));
                double sum = ventas.stream()
                        .filter(v -> {
                            if (v.getFechaVenta() == null) return false;
                            LocalDate d = v.getFechaVenta().toLocalDate();
                            return !d.isBefore(ini) && !d.isAfter(fin);
                        })
                        .mapToDouble(v -> v.getTotal() != null ? v.getTotal() : 0)
                        .sum();
                grafTotales.add(Math.round(sum * 100.0) / 100.0);
            }
        } else {
            // semestre / anio → por mes
            int meses = periodo.equals("anio") ? 12 : 6;
            for (int i = meses - 1; i >= 0; i--) {
                LocalDate mes = hoy.minusMonths(i);
                String lbl = mes.getMonth()
                        .getDisplayName(TextStyle.SHORT, new Locale("es", "SV"));
                grafLabels.add(lbl);
                double sum = ventas.stream()
                        .filter(v -> v.getFechaVenta() != null &&
                                     v.getFechaVenta().getYear()       == mes.getYear() &&
                                     v.getFechaVenta().getMonthValue() == mes.getMonthValue())
                        .mapToDouble(v -> v.getTotal() != null ? v.getTotal() : 0)
                        .sum();
                grafTotales.add(Math.round(sum * 100.0) / 100.0);
            }
        }

        model.addAttribute("grafLabels",  grafLabels);
        model.addAttribute("grafTotales", grafTotales);

        // ── Reparaciones por estado ───────────────────────────────
        Map<String, Long> repEstados = new LinkedHashMap<>();
        repEstados.put("Recibido",   reparaciones.stream().filter(r -> r.getEstado() == Reparacion.Estado.RECIBIDO).count());
        repEstados.put("En proceso", reparaciones.stream().filter(r -> r.getEstado() == Reparacion.Estado.EN_PROCESO).count());
        repEstados.put("Listo",      reparaciones.stream().filter(r -> r.getEstado() == Reparacion.Estado.LISTO).count());
        repEstados.put("Entregado",  reparaciones.stream().filter(r -> r.getEstado() == Reparacion.Estado.ENTREGADO).count());
        repEstados.put("Cancelado",  reparaciones.stream().filter(r -> r.getEstado() == Reparacion.Estado.CANCELADO).count());
        model.addAttribute("repEstados", repEstados);

        // ── Métodos de pago (del periodo) ─────────────────────────
        Map<String, Long> metodosPago = ventas.stream()
                .filter(v -> v.getMetodoPago() != null)
                .collect(Collectors.groupingBy(Venta::getMetodoPago, Collectors.counting()));
        model.addAttribute("metodosPago", metodosPago);

        // ── Ventas recientes (tabla) ──────────────────────────────
        List<Venta> ventasRecientes = ventas.stream()
                .sorted(Comparator.comparing(
                        v -> v.getFechaVenta() != null ? v.getFechaVenta() : LocalDateTime.MIN,
                        Comparator.reverseOrder()))
                .limit(8)
                .collect(Collectors.toList());
        model.addAttribute("ventasRecientes", ventasRecientes);

        // ── Reparaciones recientes (tabla) ────────────────────────
        List<Reparacion> repsRecientes = reparaciones.stream()
                .sorted(Comparator.comparing(
                        r -> r.getFechaIngreso() != null ? r.getFechaIngreso() : LocalDateTime.MIN,
                        Comparator.reverseOrder()))
                .limit(6)
                .collect(Collectors.toList());
        model.addAttribute("repsRecientes", repsRecientes);

        return "reportes/index";
    }
}