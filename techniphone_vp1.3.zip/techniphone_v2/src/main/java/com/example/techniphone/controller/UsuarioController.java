/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.techniphone.controller;

import com.example.techniphone.model.Rol;
import com.example.techniphone.model.Usuario;
import com.example.techniphone.repository.RolRepository;
import com.example.techniphone.repository.UsuarioRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 *
 * @author suria
 */
@Controller
@RequestMapping("/usuarios")
public class UsuarioController {

    private final UsuarioRepository usuarioRepo;
    private final RolRepository     rolRepo;

    public UsuarioController(UsuarioRepository usuarioRepo, RolRepository rolRepo) {
        this.usuarioRepo = usuarioRepo;
        this.rolRepo     = rolRepo;
    }

    // ── Lista ─────────────────────────────────────────────────
    @GetMapping
    public String lista(Model model) {
        List<Usuario> usuarios = usuarioRepo.findAll();
        model.addAttribute("usuarios", usuarios);
        model.addAttribute("total",    usuarios.size());
        return "usuarios/lista";
    }

    // ── Formulario nuevo ──────────────────────────────────────
    @GetMapping("/nuevo")
    public String nuevo(Model model) {
        model.addAttribute("usuario", new Usuario());
        model.addAttribute("roles",   rolRepo.findAll());
        model.addAttribute("esNuevo", true);
        return "usuarios/formulario";
    }

    // ── Guardar nuevo ─────────────────────────────────────────
    @PostMapping("/guardar")
    public String guardar(@ModelAttribute Usuario usuario,
                          @RequestParam(value = "rolId",      required = false) Long rolId,
                          @RequestParam(value = "habilitado", required = false) String habilitado,
                          RedirectAttributes ra) {
        try {
            // Manejar habilitado
            usuario.setHabilitado("true".equals(habilitado));

            // Asignar rol
            if (rolId != null) {
                Optional<Rol> rol = rolRepo.findById(rolId);
                if (rol.isPresent()) {
                    Set<Rol> roles = new HashSet<>();
                    roles.add(rol.get());
                    usuario.setRoles(roles);
                }
            }

            usuarioRepo.save(usuario);
            ra.addFlashAttribute("exito", "Usuario creado correctamente.");
        } catch (Exception e) {
            ra.addFlashAttribute("error", "Error al crear el usuario: " + e.getMessage());
        }
        return "redirect:/usuarios";
    }

    // ── Formulario editar ─────────────────────────────────────
    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model, RedirectAttributes ra) {
        Optional<Usuario> opt = usuarioRepo.findById(id);
        if (opt.isEmpty()) {
            ra.addFlashAttribute("error", "Usuario no encontrado.");
            return "redirect:/usuarios";
        }
        model.addAttribute("usuario", opt.get());
        model.addAttribute("roles",   rolRepo.findAll());
        model.addAttribute("esNuevo", false);
        return "usuarios/formulario";
    }

    // ── Actualizar ────────────────────────────────────────────
    @PostMapping("/actualizar/{id}")
    public String actualizar(@PathVariable Long id,
                             @ModelAttribute Usuario usuario,
                             @RequestParam(value = "rolId",      required = false) Long rolId,
                             @RequestParam(value = "habilitado", required = false) String habilitado,
                             RedirectAttributes ra) {
        try {
            Optional<Usuario> opt = usuarioRepo.findById(id);
            if (opt.isEmpty()) {
                ra.addFlashAttribute("error", "Usuario no encontrado.");
                return "redirect:/usuarios";
            }

            Usuario existente = opt.get();
            existente.setNombre(usuario.getNombre());
            existente.setTelefono(usuario.getTelefono());
            existente.setUsername(usuario.getUsername());
            existente.setEspecialidad(usuario.getEspecialidad());
            existente.setTurno(usuario.getTurno());

            // Manejar habilitado correctamente
            existente.setHabilitado("true".equals(habilitado));

            // Solo actualizar password si no viene vacío
            if (usuario.getPassword() != null && !usuario.getPassword().isBlank()) {
                existente.setPassword(usuario.getPassword());
            }

            // Asignar rol
            if (rolId != null) {
                Optional<Rol> rol = rolRepo.findById(rolId);
                if (rol.isPresent()) {
                    Set<Rol> roles = new HashSet<>();
                    roles.add(rol.get());
                    existente.setRoles(roles);
                }
            } else {
                existente.setRoles(new HashSet<>());
            }

            usuarioRepo.save(existente);
            ra.addFlashAttribute("exito", "Usuario actualizado correctamente.");
        } catch (Exception e) {
            ra.addFlashAttribute("error", "Error al actualizar: " + e.getMessage());
        }
        return "redirect:/usuarios";
    }

    // ── Eliminar ──────────────────────────────────────────────
    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id, RedirectAttributes ra) {
        try {
            usuarioRepo.deleteById(id);
            ra.addFlashAttribute("exito", "Usuario eliminado correctamente.");
        } catch (Exception e) {
            ra.addFlashAttribute("error", "No se pudo eliminar el usuario.");
        }
        return "redirect:/usuarios";
    }
}